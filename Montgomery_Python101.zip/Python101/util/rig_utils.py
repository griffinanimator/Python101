import maya.cmds as cmds 


def build_Joints(position, *args):
    jnt = []
    cmds.select(d=True) #deselects locator so joints won't be parented to it
    for key in sorted(position): #sorted so joints will be in correct order
        name = key.replace('lctr','jnt')
        locPos = cmds.xform(key, q=True, t=True, ws = True) #gets locator position
        buildJnt= cmds.joint(n=name, p=locPos) #creates joints in locator's position
        jnt.append(buildJnt)
        cmds.delete(key) #deletes locator
    
    for i  in range(len(jnt)):
        cmds.joint(jnt[i], e=True, zso = True, oj = 'xyz')
    return jnt