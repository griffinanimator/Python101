import sys
import os
import maya.cmds as mc

sys.path.append("D:/Users\Toby/Documents/GitHub/Python101")
mc.evalDeferred("import system.mayaCommandPort")
mc.evalDeferred("import system.startup")

