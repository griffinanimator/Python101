Python101
=========

Repository for Rigging Dojo Python 101 course.
